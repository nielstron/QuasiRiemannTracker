Argonaut Math — exact proof additions and reconstruction evidence

These proof files are by Argonaut Math and retain their original bytes. This
review bundle is not a new proof or a bound obtained from another submission.
The target is 3499999/4000000 in PerturbedBoundaryMain, with the original
Dirichlet, zeta, and Hecke exports. LICENSE and upstream attribution notices
are retained. The new verification packaging is separate from the proof.

The source/ directory contains the original project files not already present
in the accepted OpenAI foundation. All existing OAI files were checked equal
to that foundation after CRLF/LF normalization. Source manifests retain the
exact upstream byte hashes, including the original dependency overlays.

This compact archive intentionally does not duplicate the 135 MB expanded
dependency overlay. To reconstruct the complete original project:

1. Run `python3 reproducibility/fetch_original.py --output ORIGINAL` to fetch
   the exact hash-pinned v0.1.8 archive. It extracts only the outer archive;
   the original reconstruction program verifies the nested source overlay.
2. Follow ORIGINAL/Lean_Proof/BUILD.md, with all 42 dependencies pinned by
   ORIGINAL/Lean_Proof/provenance/PINS.json. Use Lean 4.34.1.
3. Build PerturbedBoundaryMain and run both original audit files, retaining
   their logs. Accept only the standard Lean axioms and the three exact target
   theorem types. The separately published mechanical evidence binds those
   inputs to the locally checked build and independent checker results.

The original reconstruction script is included verbatim as
reproducibility/upstream_reconstruct.py for review. The immutable archive is
authenticated by SHA256, not merely by its release tag.
