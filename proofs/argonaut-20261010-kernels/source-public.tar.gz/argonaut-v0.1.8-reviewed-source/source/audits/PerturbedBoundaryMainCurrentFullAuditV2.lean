import PerturbedBoundaryMain

set_option pp.universes true

#check OAI.SevenEighths.PerturbedBoundaryMain.sameDataCutoff
#print OAI.SevenEighths.PerturbedBoundaryMain.sameDataCutoff
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.PerturbedBoundaryMain.sameDataCutoff

#check OAI.SevenEighths.PerturbedBoundaryMain.sigmaBoundary_value
#print OAI.SevenEighths.PerturbedBoundaryMain.sigmaBoundary_value
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.PerturbedBoundaryMain.sigmaBoundary_value

#check OAI.SevenEighths.PerturbedBoundaryMain.principal_request_le_sameDataCutoff
#print OAI.SevenEighths.PerturbedBoundaryMain.principal_request_le_sameDataCutoff
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.PerturbedBoundaryMain.principal_request_le_sameDataCutoff

#check OAI.SevenEighths.PerturbedBoundaryMain.assembly_cutoff_le_sameDataCutoff
#print OAI.SevenEighths.PerturbedBoundaryMain.assembly_cutoff_le_sameDataCutoff
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.PerturbedBoundaryMain.assembly_cutoff_le_sameDataCutoff

#check OAI.SevenEighths.PerturbedBoundaryMain.commonProbeConstruction_current
#print OAI.SevenEighths.PerturbedBoundaryMain.commonProbeConstruction_current
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.PerturbedBoundaryMain.commonProbeConstruction_current

#check OAI.SevenEighths.PerturbedBoundaryMain.uniformCommonProbeBoundary_current
#print OAI.SevenEighths.PerturbedBoundaryMain.uniformCommonProbeBoundary_current
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.PerturbedBoundaryMain.uniformCommonProbeBoundary_current

#check OAI.SevenEighths.PerturbedBoundaryMain.hecke_current
#print OAI.SevenEighths.PerturbedBoundaryMain.hecke_current
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.PerturbedBoundaryMain.hecke_current

#check OAI.DirichletCharacter.LFunction_ne_zero_of_perturbed_boundary_lt_re
#print OAI.DirichletCharacter.LFunction_ne_zero_of_perturbed_boundary_lt_re
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.DirichletCharacter.LFunction_ne_zero_of_perturbed_boundary_lt_re

#check OAI.riemannZeta_ne_zero_of_perturbed_boundary_lt_re
#print OAI.riemannZeta_ne_zero_of_perturbed_boundary_lt_re
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.riemannZeta_ne_zero_of_perturbed_boundary_lt_re

#check OAI.SevenEighths.HeckeFamily.LFunction_ne_zero_of_perturbed_boundary_lt_re
#print OAI.SevenEighths.HeckeFamily.LFunction_ne_zero_of_perturbed_boundary_lt_re
set_option pp.all false in
set_option pp.universes false in
#print axioms OAI.SevenEighths.HeckeFamily.LFunction_ne_zero_of_perturbed_boundary_lt_re

